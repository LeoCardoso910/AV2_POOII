-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 21-Ago-2022 às 15:59
-- Versão do servidor: 10.4.22-MariaDB
-- versão do PHP: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `av-poo`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente`
--

CREATE TABLE `cliente` (
  `cod_cliente` int(11) NOT NULL,
  `cpf` bigint(14) NOT NULL,
  `nomeCliente` varchar(80) DEFAULT NULL,
  `renda` decimal(10,2) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `classe` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `cliente`
--

INSERT INTO `cliente` (`cod_cliente`, `cpf`, `nomeCliente`, `renda`, `email`, `classe`) VALUES
(25, 55343664008, 'John Kramer', '9999.00', 'jigsaw@gmail.com', 'Alta'),
(34, 76733930005, 'Michael Jack son', '12000.00', 'rusbe@gmail.com', 'Alta'),
(35, 59281213001, 'Hebe Camargo', '3000.00', 'hebe@gmail.com', 'Média');

-- --------------------------------------------------------

--
-- Estrutura da tabela `detalhevenda`
--

CREATE TABLE `detalhevenda` (
  `codVenda` int(11) NOT NULL,
  `codProduto` varchar(80) DEFAULT NULL,
  `qtdProduto` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `detalhevenda`
--

INSERT INTO `detalhevenda` (`codVenda`, `codProduto`, `qtdProduto`) VALUES
(31, '45442', '2'),
(31, '45443', '1'),
(31, '45441', '1'),
(32, '45442', '1'),
(32, '45443', '2'),
(32, '45441', '5'),
(33, '45442', '1'),
(34, '45442', '2'),
(34, '45441', '2'),
(35, '45442', '2'),
(35, '45443', '1'),
(36, '45441', '15'),
(37, '45441', '40'),
(38, '45442', '5'),
(38, '45443', '6'),
(39, '45442', '2'),
(39, '45443', '2'),
(40, '45442', '4'),
(40, '45443', '1'),
(43, '2', '4'),
(44, '2', '6'),
(44, '3', '6');

-- --------------------------------------------------------

--
-- Estrutura da tabela `produto`
--

CREATE TABLE `produto` (
  `codProduto` int(80) NOT NULL,
  `descricao` text DEFAULT NULL,
  `valorUnitario` decimal(7,2) DEFAULT NULL,
  `unidade` varchar(100) DEFAULT NULL,
  `estoqueMinimo` int(11) DEFAULT NULL,
  `qtdEstoque` int(100) DEFAULT NULL,
  `imagem` varchar(150) NOT NULL DEFAULT '../img/defaultProductImage.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `produto`
--

INSERT INTO `produto` (`codProduto`, `descricao`, `valorUnitario`, `unidade`, `estoqueMinimo`, `qtdEstoque`, `imagem`) VALUES
(1, 'Papel A4 500 Folhas', '30.00', 'UN', 10, 10, '../img/papelA4.png'),
(2, 'Televisão', '1500.00', 'UN', 20, 27, '../img/tv.png'),
(3, 'Celular', '1300.00', 'UN', 30, 54, '../img/celular.png'),
(45446, 'dsfs', '3333.00', 'LT', 8, 9, '../img/defaultProductImage.png');

-- --------------------------------------------------------

--
-- Estrutura da tabela `venda`
--

CREATE TABLE `venda` (
  `codVenda` int(11) NOT NULL,
  `codCliente` int(11) DEFAULT NULL,
  `dataVenda` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `venda`
--

INSERT INTO `venda` (`codVenda`, `codCliente`, `dataVenda`) VALUES
(43, 25, '2022-08-21'),
(44, 34, '2022-08-21');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`cod_cliente`),
  ADD UNIQUE KEY `cpf` (`cpf`);

--
-- Índices para tabela `detalhevenda`
--
ALTER TABLE `detalhevenda`
  ADD KEY `codProduto_fk` (`codProduto`);

--
-- Índices para tabela `produto`
--
ALTER TABLE `produto`
  ADD PRIMARY KEY (`codProduto`);

--
-- Índices para tabela `venda`
--
ALTER TABLE `venda`
  ADD PRIMARY KEY (`codVenda`),
  ADD KEY `fk_cliente` (`codCliente`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `cliente`
--
ALTER TABLE `cliente`
  MODIFY `cod_cliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT de tabela `produto`
--
ALTER TABLE `produto`
  MODIFY `codProduto` int(80) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45447;

--
-- AUTO_INCREMENT de tabela `venda`
--
ALTER TABLE `venda`
  MODIFY `codVenda` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `venda`
--
ALTER TABLE `venda`
  ADD CONSTRAINT `fk_cliente` FOREIGN KEY (`codCliente`) REFERENCES `cliente` (`cod_cliente`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
