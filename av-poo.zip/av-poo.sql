-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 28-Ago-2022 às 19:44
-- Versão do servidor: 10.4.22-MariaDB
-- versão do PHP: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `av-poo`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente`
--

CREATE TABLE `cliente` (
  `cod_cliente` int(11) NOT NULL,
  `cpf` varchar(11) NOT NULL,
  `nomeCliente` varchar(80) DEFAULT NULL,
  `renda` decimal(10,2) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `classe` varchar(50) DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `cliente`
--

INSERT INTO `cliente` (`cod_cliente`, `cpf`, `nomeCliente`, `renda`, `email`, `classe`, `ativo`) VALUES
(1, '26871288058', 'John Kramer', '9999.00', 'jigsaw@gmail.com', 'Alta', 1),
(2, '42359847058', 'Claudia Leite', '5000.99', 'claudia@gmail.com', 'Alta', 1),
(3, '67503914009', 'Michael Jackson', '100000.00', 'rusbe@gmail.com', 'Alta', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `detalhevenda`
--

CREATE TABLE `detalhevenda` (
  `codVenda` int(11) NOT NULL,
  `codProduto` varchar(80) NOT NULL,
  `qtdProduto` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `produto`
--

CREATE TABLE `produto` (
  `codProduto` int(80) NOT NULL,
  `descricao` text DEFAULT NULL,
  `valorUnitario` decimal(7,2) DEFAULT NULL,
  `unidade` varchar(100) DEFAULT NULL,
  `estoqueMinimo` int(11) DEFAULT NULL,
  `qtdEstoque` int(100) DEFAULT NULL,
  `imagem` varchar(150) NOT NULL DEFAULT '../public/assets/img/defaultProductImage.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `produto`
--

INSERT INTO `produto` (`codProduto`, `descricao`, `valorUnitario`, `unidade`, `estoqueMinimo`, `qtdEstoque`, `imagem`) VALUES
(1, 'Papel A4 500 Folhas', '30.00', 'UN', 10, 10, '../public/assets/img/papelA4.png'),
(2, 'Televisão', '1500.00', 'UN', 20, 20, '../public/assets/img/tv.png'),
(3, 'Celular', '1300.00', 'UN', 30, 41, '../public/assets/img/celular.png');

-- --------------------------------------------------------

--
-- Estrutura da tabela `venda`
--

CREATE TABLE `venda` (
  `codVenda` int(11) NOT NULL,
  `codCliente` int(11) DEFAULT NULL,
  `dataVenda` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`cod_cliente`),
  ADD UNIQUE KEY `cpf` (`cpf`);

--
-- Índices para tabela `detalhevenda`
--
ALTER TABLE `detalhevenda`
  ADD PRIMARY KEY (`codVenda`,`codProduto`),
  ADD KEY `codProduto_fk` (`codProduto`);

--
-- Índices para tabela `produto`
--
ALTER TABLE `produto`
  ADD PRIMARY KEY (`codProduto`);

--
-- Índices para tabela `venda`
--
ALTER TABLE `venda`
  ADD PRIMARY KEY (`codVenda`),
  ADD KEY `fk_cliente` (`codCliente`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `cliente`
--
ALTER TABLE `cliente`
  MODIFY `cod_cliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `produto`
--
ALTER TABLE `produto`
  MODIFY `codProduto` int(80) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `venda`
--
ALTER TABLE `venda`
  MODIFY `codVenda` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `detalhevenda`
--
ALTER TABLE `detalhevenda`
  ADD CONSTRAINT `fk_codVenda` FOREIGN KEY (`codVenda`) REFERENCES `venda` (`codVenda`),
  ADD CONSTRAINT `fk_vendas_codvenda` FOREIGN KEY (`codVenda`) REFERENCES `venda` (`codVenda`);

--
-- Limitadores para a tabela `venda`
--
ALTER TABLE `venda`
  ADD CONSTRAINT `fk_cliente` FOREIGN KEY (`codCliente`) REFERENCES `cliente` (`cod_cliente`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
